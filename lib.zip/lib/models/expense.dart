class Expense {
  final int? id;
  final String date;
  final String driver;
  final String truckNumber;
  final double amount;
  final String paidBy;
  final String paymentMode;
  final String expenseType;
  final String remarks;

  Expense({
    this.id,
    required this.date,
    required this.driver,
    required this.truckNumber,
    required this.amount,
    required this.paidBy,
    required this.paymentMode,
    required this.expenseType,
    required this.remarks,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'date': date,
      'driver': driver,
      'truckNumber': truckNumber,
      'amount': amount,
      'paidBy': paidBy,
      'paymentMode': paymentMode,
      'expenseType': expenseType,
      'remarks': remarks,
    };
  }
}