class Driver {
  final String name;
  final String truckNumber;

  Driver({
    required this.name,
    required this.truckNumber,
  });
}
