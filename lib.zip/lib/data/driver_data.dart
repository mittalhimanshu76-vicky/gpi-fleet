import '../models/driver.dart';

final List<Driver> drivers = [

  Driver(name: 'Tohid', truckNumber: 'HR58E7858'),
  Driver(name: 'Sayad', truckNumber: 'HR58F0458'),
  Driver(name: 'Shahnawaz', truckNumber: 'HR58F0558'),
  Driver(name: 'Ashish', truckNumber: 'UP17AT4978'),
  Driver(name: 'Rishikesh', truckNumber: 'UP12CT7758'),
  Driver(name: 'Jai Kumar', truckNumber: 'UK17CA0832'),
  Driver(name: 'Rishipal', truckNumber: 'UP12AT2311'),
  Driver(name: 'Wazid', truckNumber: 'UP12AT7758'),
  Driver(name: 'Jameel', truckNumber: 'UK17CA4996'),
  Driver(name: 'Mukesh', truckNumber: 'UP12AT1758'),
  Driver(name: 'Khalid', truckNumber: 'UP12AT3858'),
  Driver(name: 'Mamsad', truckNumber: 'UP13AT8999'),
  Driver(name: 'Yaseen', truckNumber: 'UP12AT7111'),
  Driver(name: 'Wahid', truckNumber: 'UP12AT4158'),
  Driver(name: 'Sukkha', truckNumber: 'UP12AT6558'),
  Driver(name: 'New Driver', truckNumber: 'UP17AT4968'),

];