import 'package:flutter/material.dart';
import '../data/driver_data.dart';
import '../models/driver.dart';


class AddExpenseScreen extends StatefulWidget {
  const AddExpenseScreen({super.key});

  @override
  State<AddExpenseScreen> createState() => _AddExpenseScreenState();
}

class _AddExpenseScreenState extends State<AddExpenseScreen> {

  Driver? selectedDriver;

  final amountController = TextEditingController();
  final remarksController = TextEditingController();

  String paidBy = "Ankur";
  String paymentMode = "Cash";
  String expenseType = "Diesel";

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        title: const Text("New Expense"),
      ),

      body: SingleChildScrollView(

        padding: const EdgeInsets.all(16),

        child: Column(

          crossAxisAlignment: CrossAxisAlignment.start,

          children: [

            const Text(
              "Driver",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 8),

            DropdownButtonFormField<Driver>(

              value: selectedDriver,

              decoration: const InputDecoration(
                border: OutlineInputBorder(),
              ),

              items: drivers.map((driver) {

                return DropdownMenuItem(
                  value: driver,
                  child: Text(driver.name),
                );

              }).toList(),

              onChanged: (value) {

                setState(() {
                  selectedDriver = value;
                });

              },

            ),

            const SizedBox(height: 20),

            TextField(

              readOnly: true,

              decoration: InputDecoration(

                border: const OutlineInputBorder(),

                labelText: "Truck Number",

                hintText:
                selectedDriver == null
                    ? ""
                    : selectedDriver!.truckNumber,

              ),

            ),

            const SizedBox(height: 20),

            TextField(

              controller: amountController,

              keyboardType: TextInputType.number,

              decoration: const InputDecoration(
                labelText: "Amount",
                border: OutlineInputBorder(),
              ),

            ),

            const SizedBox(height: 20),

            DropdownButtonFormField<String>(

              value: paidBy,

              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Paid By",
              ),

              items: const [

                DropdownMenuItem(
                  value: "Ankur",
                  child: Text("Ankur"),
                ),

                DropdownMenuItem(
                  value: "Himanshu",
                  child: Text("Himanshu"),
                ),

                DropdownMenuItem(
                  value: "Mukesh",
                  child: Text("Mukesh"),
                ),

              ],

              onChanged: (v) {

                setState(() {
                  paidBy = v!;
                });

              },

            ),

            const SizedBox(height: 20),

            DropdownButtonFormField<String>(

              value: paymentMode,

              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Payment Mode",
              ),

              items: const [

                DropdownMenuItem(
                  value: "Cash",
                  child: Text("Cash"),
                ),

                DropdownMenuItem(
                  value: "UPI",
                  child: Text("UPI"),
                ),

                DropdownMenuItem(
                  value: "PhonePe",
                  child: Text("PhonePe"),
                ),

                DropdownMenuItem(
                  value: "Bank",
                  child: Text("Bank"),
                ),

              ],

              onChanged: (v) {

                setState(() {
                  paymentMode = v!;
                });

              },

            ),

            const SizedBox(height: 20),

            DropdownButtonFormField<String>(

              value: expenseType,

              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Expense Type",
              ),

              items: const [

                DropdownMenuItem(
                  value: "Diesel",
                  child: Text("Diesel"),
                ),

                DropdownMenuItem(
                  value: "Toll",
                  child: Text("Toll"),
                ),

                DropdownMenuItem(
                  value: "Food",
                  child: Text("Food"),
                ),

                DropdownMenuItem(
                  value: "Repair",
                  child: Text("Repair"),
                ),

                DropdownMenuItem(
                  value: "Parking",
                  child: Text("Parking"),
                ),

                DropdownMenuItem(
                  value: "Advance",
                  child: Text("Advance"),
                ),

                DropdownMenuItem(
                  value: "Other",
                  child: Text("Other"),
                ),

              ],

              onChanged: (v) {

                setState(() {
                  expenseType = v!;
                });

              },

            ),

            const SizedBox(height: 20),

            TextField(

              controller: remarksController,

              maxLines: 3,

              decoration: const InputDecoration(

                border: OutlineInputBorder(),

                labelText: "Remarks",

              ),

            ),

            const SizedBox(height: 30),

            SizedBox(

              width: double.infinity,

              height: 55,

              child: ElevatedButton(

                onPressed: () {

                  ScaffoldMessenger.of(context).showSnackBar(

                    const SnackBar(
                      content: Text("Expense Saved (Database in next step)"),
                    ),

                  );

                },

                child: const Text(
                  "SAVE",
                  style: TextStyle(fontSize: 18),
                ),

              ),

            ),

          ],

        ),

      ),

    );
  }
}