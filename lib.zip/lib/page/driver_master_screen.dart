import 'package:flutter/material.dart';

class DriverMasterScreen extends StatefulWidget {
  const DriverMasterScreen({super.key});

  @override
  State<DriverMasterScreen> createState() => _DriverMasterScreenState();
}

class _DriverMasterScreenState extends State<DriverMasterScreen> {
  final TextEditingController _driverController = TextEditingController();

  final List<String> drivers = [];

  void addDriver() {
    if (_driverController.text.trim().isEmpty) return;

    setState(() {
      drivers.add(_driverController.text.trim());
      _driverController.clear();
    });
  }

  void deleteDriver(int index) {
    setState(() {
      drivers.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Driver Master"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [

            TextField(
              controller: _driverController,
              decoration: InputDecoration(
                labelText: "Driver Name",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),

            const SizedBox(height: 15),

            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton.icon(
                onPressed: addDriver,
                icon: const Icon(Icons.add),
                label: const Text("Add Driver"),
              ),
            ),

            const SizedBox(height: 20),

            Expanded(
              child: drivers.isEmpty
                  ? const Center(
                child: Text(
                  "No Drivers Added",
                  style: TextStyle(fontSize: 18),
                ),
              )
                  : ListView.builder(
                itemCount: drivers.length,
                itemBuilder: (context, index) {
                  return Card(
                    child: ListTile(
                      leading: const Icon(Icons.person),
                      title: Text(drivers[index]),
                      trailing: IconButton(
                        icon: const Icon(
                          Icons.delete,
                          color: Colors.red,
                        ),
                        onPressed: () => deleteDriver(index),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}