import 'package:flutter/material.dart';
import 'add_expense_screen.dart';
import 'masters_screen.dart';
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Widget menuButton(
      BuildContext context,
      IconData icon,
      String title,
      Color color,
      VoidCallback onPressed,
      ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: SizedBox(
        width: double.infinity,
        height: 65,
        child: ElevatedButton.icon(
          style: ElevatedButton.styleFrom(
            backgroundColor: color,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
          ),
          onPressed: onPressed,
          icon: Icon(icon, size: 28),
          label: Text(
            title,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget summaryCard(String title, String amount, Color color) {
    return Card(
      elevation: 5,
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color,
          child: const Icon(Icons.currency_rupee, color: Colors.white),
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          amount,
          style: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("🚛 GPI Fleet"),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [

            const Text(
              "Gautam Parkash India Pvt. Ltd.",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 20),

            summaryCard(
              "Today's Expense",
              "₹0",
              Colors.blue,
            ),

            summaryCard(
              "This Month",
              "₹0",
              Colors.green,
            ),

            const SizedBox(height: 20),

            menuButton(
              context,
              Icons.add_circle,
              "New Expense",
              Colors.blue,
                  () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const AddExpenseScreen(),
                  ),
                );
              },
            ),

            menuButton(
              context,
              Icons.history,
              "Expense History",
              Colors.green,
                  () {},
            ),

            menuButton(
              context,
              Icons.bar_chart,
              "Reports",
              Colors.orange,
                  () {},
            ),

            menuButton(
              context,
              Icons.settings,
              "Masters",
              Colors.purple,
                  () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const MastersScreen(),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}