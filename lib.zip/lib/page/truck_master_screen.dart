import 'package:flutter/material.dart';

class TruckMasterScreen extends StatefulWidget {
  const TruckMasterScreen({super.key});

  @override
  State<TruckMasterScreen> createState() => _TruckMasterScreenState();
}

class _TruckMasterScreenState extends State<TruckMasterScreen> {
  final TextEditingController _truckController = TextEditingController();

  final List<String> trucks = [];

  void addTruck() {
    if (_truckController.text.trim().isEmpty) return;

    setState(() {
      trucks.add(_truckController.text.trim().toUpperCase());
      _truckController.clear();
    });
  }

  void deleteTruck(int index) {
    setState(() {
      trucks.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Truck Master"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [

            TextField(
              controller: _truckController,
              textCapitalization: TextCapitalization.characters,
              decoration: InputDecoration(
                labelText: "Truck Number",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),

            const SizedBox(height: 15),

            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton.icon(
                onPressed: addTruck,
                icon: const Icon(Icons.add),
                label: const Text("Add Truck"),
              ),
            ),

            const SizedBox(height: 20),

            Expanded(
              child: trucks.isEmpty
                  ? const Center(
                child: Text(
                  "No Trucks Added",
                  style: TextStyle(fontSize: 18),
                ),
              )
                  : ListView.builder(
                itemCount: trucks.length,
                itemBuilder: (context, index) {
                  return Card(
                    child: ListTile(
                      leading: const Icon(Icons.local_shipping),
                      title: Text(trucks[index]),
                      trailing: IconButton(
                        icon: const Icon(
                          Icons.delete,
                          color: Colors.red,
                        ),
                        onPressed: () => deleteTruck(index),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}